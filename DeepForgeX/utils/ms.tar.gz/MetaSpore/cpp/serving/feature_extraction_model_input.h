//
// Copyright 2022 DMetaSoul
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#pragma once

#include <unordered_map>

#include <serving/model_base.h>

#include <arrow/record_batch.h>

namespace metaspore::serving {

class FeatureExtractionModelInput : public ModelInputBase {
  public:
    std::unordered_map<std::string, std::shared_ptr<arrow::RecordBatch>> feature_tables;
};

} // namespace metaspore::serving